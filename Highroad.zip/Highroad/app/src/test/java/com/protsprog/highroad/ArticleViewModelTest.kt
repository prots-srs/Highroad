package com.protsprog.highroad

/*
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.protsprog.highroad.articles.ArticleViewModel
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ArticleViewModelTest {
    @Test
    fun addNewArticle_setsNewArticleEvent() {
        // Given a fresh ArticleViewModel
        val articleViewModel = ArticleViewModel(ApplicationProvider.getApplicationContext())


//        val articlesRepository = ArticlesRepository(HighroadDatabase.getDatabase(application))
//        val articleList = ArticlesApi.service.getList()
//        Log.d("NETWORK GET", articleList.toString())



        // When adding a new article


        // Then the new article event is triggered
    }
}
*/