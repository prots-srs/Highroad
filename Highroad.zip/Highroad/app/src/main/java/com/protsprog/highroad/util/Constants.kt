package com.protsprog.highroad.util

const val SHARED_PREFS_FILENAME = "biometric_prefs"
const val CIPHERTEXT_WRAPPER = "ciphertext_wrapper"

const val API_SERVER = "https://protsprog.com/"
//const val API_SERVER = "http://192.168.50.107/"