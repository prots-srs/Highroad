package com.protsprog.highroad.glance.theme

/*
TO READ

https://imagecolorpicker.com/en
 */
import androidx.compose.ui.graphics.Color

val md_theme_light_primary = Color(0xFF0f5792)
val md_theme_light_onPrimary = Color(0xFFD3EFF0)
val md_theme_light_primaryContainer = Color(0xFFe28743)
val md_theme_light_onPrimaryContainer = Color(0xFF873e23)
//val md_theme_light_surface = Color(0xFF873e23)
//val md_theme_light_onSurface = Color(0xFFe28743)

val md_theme_dark_primary = Color(0xFF0f5792)
val md_theme_dark_onPrimary = Color(0xFFD3EFF0)
val md_theme_dark_primaryContainer = Color(0xFFe28743)
val md_theme_dark_onPrimaryContainer = Color(0xFF873e23)
//val md_theme_dark_surface = Color(0xFF873e23)
//val md_theme_dark_onSurface = Color(0xFFe28743)