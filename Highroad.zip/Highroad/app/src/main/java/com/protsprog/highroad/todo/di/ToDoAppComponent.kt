package com.protsprog.highroad.todo.di

import androidx.glance.appwidget.GlanceAppWidget
import com.protsprog.highroad.HighroadApplication
import com.protsprog.highroad.MainActivity
import dagger.Component
import javax.inject.Singleton

/*
@Singleton
@Component(modules = [ToDoDbModule::class])
interface ToDoAppComponent {
//    fun inject(activity: MainActivity)
    fun inject(widget: GlanceAppWidget)
}

 */