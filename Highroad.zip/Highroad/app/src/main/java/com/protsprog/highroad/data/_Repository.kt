package com.protsprog.highroad.data

/*
override suspend fun getDetailAgentVisitWithFullResponse(id: Int): SallyResponseResource<BaseResponse<GetAgentDetailResponse>> {
    return agentVisitDataSource.getDetailAgentVisitFullResponse(
        token = "",
        id = id
    )
}

override fun getDetailAgentVisitFullResponseFlow(id: Int): Flow<SallyResponseResource<BaseResponse<GetAgentDetailResponse>>> {
    return agentVisitDataSource.getDetailAgentVisitFullResponseFlow(
        token = "",
        id = id
    ).asSallyResponseResourceFlow()
}
*/