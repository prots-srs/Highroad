package com.protsprog.highroad

class ApplicationViewModel {

}

