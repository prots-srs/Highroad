package com.protsprog.highroad.compose.animating.ui.theme

import androidx.compose.ui.graphics.Color

val Purple100 = Color(0xFFE1BEE7)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Green300 = Color(0xFF81C784)
val Green800 = Color(0xFF2E7D32)
val Amber600 = Color(0xFFFFB300)
