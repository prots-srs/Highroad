package com.protsprog.highroad.compose.datastore.data

object LocalDessertReleaseData {
    val dessertReleases = listOf(
        "Cupcake",
        "Donut",
        "Eclair",
        "Froyo",
        "Gingerbread",
        "Honeycomb",
        "Ice Cream Sandwich",
        "Jelly Bean",
        "KitKat",
        "Lollipop",
        "Marshmallow",
        "Nougat",
        "Oreo",
        "Pie",
        "Quince Tart",
        "Red Velvet Cake",
        "Snow Cone",
        "Tiramisu"
    )
}