package com.protsprog.highroad.authentication.domen

object AuthAppLogin {
    var token: String? = null
    var email: String? = null
    var password: String? = null
}