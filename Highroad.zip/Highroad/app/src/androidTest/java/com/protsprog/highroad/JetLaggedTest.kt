package com.protsprog.highroad

//import androidx.compose.ui.test.assertIsDisplayed
//import androidx.compose.ui.test.junit4.createComposeRule
//import androidx.compose.ui.test.onNodeWithText
//import com.protsprog.highroad.compose.customlayout.JetLaggedScreen
//import org.junit.Before
//import org.junit.Rule
//import org.junit.Test

//class JetLaggedTest {
//
//    @get:Rule
//    val composeTestRule = createComposeRule()
//
//    @Before
//    fun setUp() {
//        composeTestRule.setContent {
//            JetLaggedScreen()
//        }
//    }
//
//    @Test
//    fun app_launches() {
//         Check app launches at the correct destination
//        composeTestRule.onNodeWithText("JetLagged").assertIsDisplayed()
//    }
//}